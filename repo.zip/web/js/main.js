$(function(){
	$('*[rel="tooltip"]').tooltip();
	
	
});
