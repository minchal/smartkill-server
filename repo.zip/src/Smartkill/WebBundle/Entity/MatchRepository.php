<?php

namespace Smartkill\WebBundle\Entity;

use Doctrine\ORM\EntityRepository;

/**
 * MatchRepository
 */
class MatchRepository extends EntityRepository {
	
}
