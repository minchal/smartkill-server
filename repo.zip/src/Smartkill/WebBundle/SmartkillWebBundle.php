<?php

namespace Smartkill\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartkillWebBundle extends Bundle
{
}
