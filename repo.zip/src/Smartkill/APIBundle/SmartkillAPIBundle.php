<?php

namespace Smartkill\APIBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartkillAPIBundle extends Bundle
{
}
